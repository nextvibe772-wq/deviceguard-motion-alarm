package com.deviceguard.motion

import android.Manifest
import android.content.*
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    private lateinit var repo: SettingsRepository
    private var hasAccel = true
    private var hasGyro = true
    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()){}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        repo = SettingsRepository(this)
        val sm = getSystemService(SENSOR_SERVICE) as SensorManager
        hasAccel = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) != null
        hasGyro = sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE) != null
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        setContent { App() }
    }
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.getBooleanExtra("showAlarm", false)) setContent { App(showAlarmFirst = true) }
    }

    @Composable
    fun App(showAlarmFirst: Boolean = false) {
        var screen by remember { mutableStateOf(if (showAlarmFirst) "alarm" else "home") }
        var state by remember { mutableStateOf(ProtectionState.OFF) }
        val settings by repo.settings.collectAsState()
        MaterialTheme(colorScheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()) {
            when (screen) {
                "alarm" -> AlarmScreen(onStop = {
                    AlarmController.stop()
                    startService(Intent(this, MotionService::class.java).setAction(MotionService.ACTION_STOP_ALARM))
                    state = if (MotionService.isRunning) ProtectionState.ACTIVE else ProtectionState.OFF
                    screen = "home"
                })
                "settings" -> SettingsScreen(settings, onBack = { screen = "home" })
                else -> HomeScreen(state, settings,
                    onArm = {
                        startForegroundService(Intent(this, MotionService::class.java).setAction(MotionService.ACTION_START))
                        state = ProtectionState.ACTIVE
                    },
                    onDisarm = {
                        if (settings.pinEnabled && repo.hasPin()) { screen = "pin" } else {
                            startService(Intent(this, MotionService::class.java).setAction(MotionService.ACTION_STOP))
                            AlarmController.stop(); state = ProtectionState.OFF
                        }
                    },
                    onTest = {
                        val s = repo.settings.value
                        AlarmController.start(this, s.soundEnabled, s.vibrationEnabled)
                        NotificationHelper.createChannel(this)
                        NotificationHelper.showAlarmHeadsUp(this)
                        screen = "alarm"
                    },
                    onSettings = { screen = "settings" })
            }
            if (screen == "pin") PinScreen(onOk = { pin ->
                if (pin == repo.getPin()) {
                    startService(Intent(this, MotionService::class.java).setAction(MotionService.ACTION_STOP))
                    AlarmController.stop(); state = ProtectionState.OFF; screen = "home"
                }
            }, onCancel = { screen = "home" })
        }
        // poll alarm state to auto-show alarm screen
        LaunchedEffect(Unit) {
            while (true) {
                delay(500)
                if (AlarmController.alarmActive && screen == "home") { state = ProtectionState.ALARM; screen = "alarm" }
            }
        }
    }

    @Composable
    fun HomeScreen(state: ProtectionState, settings: AppSettings, onArm: ()->Unit, onDisarm: ()->Unit, onTest: ()->Unit, onSettings: ()->Unit) {
        var score by remember { mutableStateOf(0f) }
        LaunchedEffect(state) { while (state==ProtectionState.ACTIVE) { delay(500); score = MotionService.motionScore } }
        val (label, color) = when(state){
            ProtectionState.OFF -> "🟢 PROTECTION OFF" to Color(0xFF2E7D32)
            ProtectionState.ACTIVE -> "🔴 PROTECTION ACTIVE" to Color(0xFFB71C1C)
            ProtectionState.ALARM -> "🚨 ALARM ACTIVE" to Color(0xFFB71C1C)
            else -> "🟠 ARMING..." to Color(0xFFEF6C00)
        }
        Column(Modifier.fillMaxSize().padding(20.dp).verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally) {
            Text("🛡️ DeviceGuard", fontSize = 30.sp, fontWeight = FontWeight.Bold)
            Text("Motion Anti-Theft Alarm", color = Color.Gray)
            Spacer(Modifier.height(16.dp))
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = color.copy(alpha=.12f))) {
                Text(label, Modifier.padding(16.dp), fontWeight = FontWeight.Bold, color = color)
            }
            Spacer(Modifier.height(12.dp))
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("Motion Level: ${motionLevelText(score, settings)}", fontWeight = FontWeight.SemiBold)
                    Text("Accelerometer: ${if(hasAccel) "Available" else "Missing"}")
                    Text("Gyroscope: ${if(hasGyro) "Available" else "Unavailable. Using accelerometer only."}")
                    if (!hasAccel) Text("This device does not provide an accelerometer. Motion protection cannot operate.", color = Color.Red)
                    Text("Note: detects physical movement/handling, not every stationary screen touch.", color = Color.Gray, fontSize = 12.sp)
                }
            }
            Spacer(Modifier.height(16.dp))
            if (state==ProtectionState.ACTIVE) Text("Protection active. Keep the device still.", color = color)
            Spacer(Modifier.height(8.dp))
            Button(onClick = onArm, enabled = hasAccel && state==ProtectionState.OFF, modifier = Modifier.fillMaxWidth().height(56.dp)) { Text("ARM DEVICE") }
            Spacer(Modifier.height(8.dp))
            Button(onClick = onDisarm, enabled = state!=ProtectionState.OFF, modifier = Modifier.fillMaxWidth().height(56.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF616161))) { Text("DISARM DEVICE") }
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = onTest, modifier = Modifier.fillMaxWidth().height(56.dp)) { Text("TEST ALARM") }
            Spacer(Modifier.height(8.dp))
            TextButton(onClick = onSettings) { Text("⚙️ Settings") }
        }
    }
    private fun motionLevelText(score: Float, s: AppSettings): String {
        val t = when(s.sensitivity){ Sensitivity.LOW->2.2f; Sensitivity.MEDIUM->1.2f; Sensitivity.HIGH->0.6f }
        return when { score < t*0.5f -> "LOW"; score < t -> "MEDIUM"; else -> "HIGH" }
    }

    @Composable
    fun AlarmScreen(onStop: ()->Unit) {
        Column(Modifier.fillMaxSize().background(Color(0xFF7F0000)).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text("🚨", fontSize = 72.sp)
            Text("DEVICE MOVEMENT DETECTED", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 22.sp)
            Text("Someone may have moved your device.", color = Color.White)
            Spacer(Modifier.height(24.dp))
            Button(onClick = onStop, modifier = Modifier.fillMaxWidth().height(64.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Red)) {
                Text("🔕 STOP ALARM", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            }
        }
    }

    @Composable
    fun PinScreen(onOk: (String)->Unit, onCancel: ()->Unit) {
        var pin by remember { mutableStateOf("") }
        Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text("Enter PIN to disarm", fontWeight = FontWeight.Bold, fontSize = 20.sp)
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(value = pin, onValueChange = { pin = it }, label = { Text("PIN") })
            Spacer(Modifier.height(12.dp))
            Button(onClick = { onOk(pin) }, Modifier.fillMaxWidth()) { Text("Confirm") }
            TextButton(onClick = onCancel) { Text("Cancel") }
        }
    }

    @Composable
    fun SettingsScreen(s: AppSettings, onBack: ()->Unit) {
        var sensitivity by remember { mutableStateOf(s.sensitivity) }
        var confirm by remember { mutableStateOf(s.confirmationMs.toFloat()) }
        var vib by remember { mutableStateOf(s.vibrationEnabled) }
        var snd by remember { mutableStateOf(s.soundEnabled) }
        var pinOn by remember { mutableStateOf(s.pinEnabled) }
        var newPin by remember { mutableStateOf("") }
        fun persist() = repo.update(AppSettings(sensitivity, confirm.toInt(), vib, snd, pinOn))
        Column(Modifier.fillMaxSize().padding(20.dp).verticalScroll(rememberScrollState())) {
            Text("Settings", fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            Text("Sensitivity (HIGH is more sensitive, may cause false alarms)")
            Row { Sensitivity.values().forEach { lv ->
                FilterChip(selected = sensitivity==lv, onClick = { sensitivity=lv; persist() }, label = { Text(lv.name) }, modifier = Modifier.padding(4.dp))
            }}
            Spacer(Modifier.height(8.dp))
            Text("Confirmation duration: ${confirm.toInt()} ms (300–3000)")
            Slider(value = confirm, onValueChange = { confirm = it; persist() }, valueRange = 300f..3000f)
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) { Text("Vibration"); Switch(vib, { vib=it; persist() }) }
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) { Text("Alarm sound"); Switch(snd, { snd=it; persist() }) }
            Text("Alarm volume guidance: use the device volume buttons to set ALARM volume to maximum for best protection.", fontSize=12.sp, color=Color.Gray)
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) { Text("Enable PIN"); Switch(pinOn, { pinOn=it; persist() }) }
            if (pinOn) {
                OutlinedTextField(newPin, { newPin = it }, label = { Text("Set new PIN") }, modifier = Modifier.fillMaxWidth())
                Button(onClick = { if (newPin.isNotBlank()) { repo.setPin(newPin); newPin="" } }, Modifier.fillMaxWidth()) { Text("Save PIN") }
            }
            Spacer(Modifier.height(8.dp))
            Button(onClick = { repo.reset() }, Modifier.fillMaxWidth()) { Text("Reset Settings") }
            Spacer(Modifier.height(8.dp))
            Text("About: DeviceGuard is a local motion anti-theft alarm. It detects physical movement/handling using device sensors. It does not guarantee detection of every touch and does not measure exact distance.", fontSize=12.sp, color=Color.Gray)
            Spacer(Modifier.height(12.dp))
            OutlinedButton(onClick = onBack, Modifier.fillMaxWidth()) { Text("Back") }
        }
    }
}
