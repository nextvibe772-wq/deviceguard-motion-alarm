package com.deviceguard.motion

import android.app.Service
import android.content.Intent
import android.hardware.*
import android.os.*
import androidx.core.app.NotificationManagerCompat

class MotionService : Service(), SensorEventListener {
    companion object {
        const val ACTION_START = "com.deviceguard.motion.START"
        const val ACTION_STOP = "com.deviceguard.motion.STOP"
        const val ACTION_STOP_ALARM = "com.deviceguard.motion.STOP_ALARM"
        var isRunning = false
        var motionScore: Float = 0f
    }
    private lateinit var sensorManager: SensorManager
    private var accel: Sensor? = null
    private var gyro: Sensor? = null
    private var detector = MotionDetector()
    private lateinit var settings: SettingsRepository
    private var ax=0f; private var ay=0f; private var az=0f
    private var baselineUntil = 0L

    override fun onCreate() {
        super.onCreate()
        settings = SettingsRepository(this)
        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        accel = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        gyro = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE)
        NotificationHelper.createChannel(this)
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP_ALARM -> {
                AlarmController.stop()
                startForeground(NotificationHelper.NOTIF_ID, NotificationHelper.protectionNotification(this))
            }
            ACTION_STOP -> { stopAll(); stopSelf(); return START_NOT_STICKY }
            else -> {
                val s = settings.settings.value
                detector.updateSettings(s.sensitivity, s.confirmationMs)
                detector.reset()
                baselineUntil = SystemClock.elapsedRealtime() + 1500L
                startForeground(NotificationHelper.NOTIF_ID, NotificationHelper.protectionNotification(this))
                accel?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL) }
                gyro?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL) }
                isRunning = true
            }
        }
        return START_STICKY
    }
    override fun onSensorChanged(e: SensorEvent) {
        if (SystemClock.elapsedRealtime() < baselineUntil) return
        var hasGyro = false; var gx=0f; var gy=0f; var gz=0f
        if (e.sensor.type == Sensor.TYPE_ACCELEROMETER) { ax=e.values[0]; ay=e.values[1]; az=e.values[2] }
        if (e.sensor.type == Sensor.TYPE_GYROSCOPE) { gx=e.values[0]; gy=e.values[1]; gz=e.values[2]; hasGyro=true }
        val s = settings.settings.value
        motionScore = detector.onSensor(ax, ay, az, gx, gy, gz, gyro != null,
            SystemClock.elapsedRealtime(), onConfirmed = {
                AlarmController.start(this, s.soundEnabled, s.vibrationEnabled)
                NotificationHelper.showAlarmHeadsUp(this)
                startForeground(NotificationHelper.NOTIF_ID, NotificationHelper.alarmNotification(this))
                val i = Intent(this, MainActivity::class.java).putExtra("showAlarm", true)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                startActivity(i)
            })
    }
    override fun onAccuracyChanged(s: Sensor?, a: Int) {}
    private fun stopAll() {
        try { sensorManager.unregisterListener(this) } catch (e: Exception) {}
        AlarmController.stop()
        isRunning = false
        try { NotificationManagerCompat.from(this).cancelAll() } catch (e: Exception) {}
    }
    override fun onDestroy() { stopAll(); super.onDestroy() }
    override fun onBind(i: Intent?): IBinder? = null
}
