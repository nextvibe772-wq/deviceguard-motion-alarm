package com.deviceguard.motion

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat

object NotificationHelper {
    const val CHANNEL_ID = "deviceguard_alarm"
    const val NOTIF_ID = 1001

    fun createChannel(ctx: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(CHANNEL_ID, "DeviceGuard Alarm", NotificationManager.IMPORTANCE_HIGH)
            ch.description = "Motion anti-theft alerts"
            (ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        }
    }
    private fun stopIntent(ctx: Context): PendingIntent {
        val i = Intent(ctx, StopAlarmReceiver::class.java).setAction("com.deviceguard.motion.STOP_ALARM")
        return PendingIntent.getBroadcast(ctx, 0, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }
    fun protectionNotification(ctx: Context): Notification {
        val open = PendingIntent.getActivity(ctx, 1, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(ctx, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle("DeviceGuard Alert")
            .setContentText("Protection active. Keep the device still.")
            .setContentIntent(open).setOngoing(true).build()
    }
    fun alarmNotification(ctx: Context): Notification {
        return NotificationCompat.Builder(ctx, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle("DeviceGuard Alert")
            .setContentText("Device movement detected.")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "STOP ALARM", stopIntent(ctx))
            .setOngoing(true).build()
    }
    fun showAlarmHeadsUp(ctx: Context) {
        (ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
            .notify(NOTIF_ID + 1, alarmNotification(ctx))
    }
}
